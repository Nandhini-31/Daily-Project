package com.src;

public class Book {
	private int bookid;
	private String name;
	private String bookauthor;
	private String bookgenre;
	private int bookcost;

	public Book() {
	}

	public int getBookid() {
		return bookid;
	}

	public void setBookid(int bookid) {
		this.bookid = bookid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBookauthor() {
		return bookauthor;
	}

	public void setBookauthor(String bookauthor) {
		this.bookauthor = bookauthor;
	}

	public String getBookgenre() {
		return bookgenre;
	}

	public void setBookgenre(String bgenre) {
		this.bookgenre = bookgenre;
	}

	public int getBookcost() {
		return bookcost;
	}

	public void setBookcost(int bookcost) {
		this.bookcost = bookcost;
	}

	@Override
	public String toString() {
		return "Book [bookid=" + bookid + ", name=" + name + ", bookauthor=" + bookauthor + ", bookgenre=" + bookgenre + ", bookcost="
				+ bookcost + "]";
	}

}
